const imagem = document.getElementById("imagem");

onload = () => {
    imagem.src = "imagens/janelafechada.png";
}

imagem.addEventListener("mouseenter", () => {
    imagem.src = "imagens/janelaaberta.png";
});

imagem.addEventListener("mouseleave", () => {
    imagem.src = "imagens/janelafechada.png";
});

imagem.addEventListener("click", () => {
    imagem.src = "imagens/janelaquebra.png";
});