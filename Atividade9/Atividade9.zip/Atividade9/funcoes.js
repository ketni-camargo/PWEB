var numero = Array(3);
var maiornum = 0;

for(i=0; i<numero.length; i++){
numero[i] = parseInt(prompt("Digite um número"));

}
function maiornumero(){
    
    return Math.max.apply(null,arguments);

    }

alert("O maior número é " + maiornumero.apply(null,numero));

function ordenado(s){
    var x = s.slice(0); /*a partir da posicao 0*/
    return x.sort(function(a,b){return a-b});
    
    
}

alert("Lista " + ordenado(numero));

