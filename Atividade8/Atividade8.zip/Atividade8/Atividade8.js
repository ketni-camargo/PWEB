var i = parseInt("0");
    var totalIdade = 0;
    var idadeMaisVelha = 0;
    var idadeMaisNova = 200;
    var pessimo = 0;
    var otimoEbom = 0;
    var mulher = 0;
    var homem = 0;
    var porc = 0;


    for(i=0; i<=44; i++){
        idade = parseInt(prompt("Qual sua idade?"));
        sexo= prompt("Qual seu sexo? \n1 - Feminino \n2 - Masculino");
        opiniao = parseInt(prompt("Qual sua opinião? \n4 - Ótimo \n3 - Bom \n2 - Regular \n1 - Péssimo "));
        totalIdade += idade;
        if(opiniao == 1)
            pessimo += 1;
            
        if(opiniao == 4 || opiniao ==3)
            otimoEbom += 1;
        
        if(sexo == 1)
            mulher += 1;
        else
            homem += 1;
        if (idade > idadeMaisVelha) 
            idadeMaisVelha = idade;

        if (idade < idadeMaisNova)
        idadeMaisNova = idade;
       
    }

   
    media = totalIdade /45; //valor de teste
    porc = (100 * otimoEbom ) / i;

    alert("Media das idades = " + media +"\n "+ "Quantidade de pessoas que responderam péssimo = " + pessimo);
    alert("A porcentagem de pessoas que responderam ótimo e bom = " + porc + "%");
    alert("Quantidade de homens é = " + homem);
    alert("A quantidade de mulheres é = " + mulher);
    alert("A idade mais velha é = " + idadeMaisVelha);
    alert("A idade mais nova é = " + idadeMaisNova);
